"""Automation Framework level settings."""
from pathlib import Path

# Report settings
CUSTOM_REPORT_NAME = "du-dubai-cis-test-report"
OPEN_REPORTS = True
ARCHIVE_REPORTS = True

# PATHS
BASE_DIR = Path(__file__).resolve().parent.parent
print(BASE_DIR)
TESTDATA_PATH = BASE_DIR / "src" / "testdata"
JSON_TESTDATA_PATH = TESTDATA_PATH
LOGS_PATH = BASE_DIR / "logs-reports"
ARCHIVE_PATH = BASE_DIR / "archive"
LIBRARIES_PATH = BASE_DIR / "src" / "libraries"
SUITES_PATH = BASE_DIR / "src" / "test-suites"
IMAGES_PATH = BASE_DIR / "config" / "images"
REQUESTS_PATH = BASE_DIR / "src" / "requests"

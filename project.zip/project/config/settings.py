"""Project level settings."""
import os

# AIR API settings
# AIR_URL = "http://10.95.214.166:10011/Air"
AIR_URL = "http://10.184.59.135:10011/Air"
# AIR_URL = "http://10.95.214.165:10011/Air"
AIR_USER_AGENT = "UGw Server/5.0/1.0"
AIR_AUTHORIZATION = os.environ["AIR_AUTHORIZATION"]
# AIR_AUTHORIZATION = os.environ["AIR_AUTHORIZATION"]

TRANSACTION_CURRENCY = "AED"

# RUN_VERIFY_CHARGING_STEP = True

# # Business API settings
SDP_URL = "http://10.184.44.156:5000/cisBusiness/sdpservice/httpService"
USSD_URL = "http://10.184.44.156:5000/cisBusiness/ussd/httpService"

FULFILLMENT_API_URL = "http://10.184.44.156:5000/cisBusiness/service/fulfillmentService"

TIBCO_USERNAME = os.environ["TIBCO_USERNAME"]
TIBCO_PASSWORD = os.environ["TIBCO_PASSWORD"]

HPSA_USERNAME = os.environ["HPSA_USERNAME"]
HPSA_PASSWORD = os.environ["HPSA_PASSWORD"]

MPOS_USERNAME = os.environ["MPOS_USERNAME"]
MPOS_PASSWORD = os.environ["MPOS_PASSWORD"]

# CIS UI settings

CIS_URL = "http://10.184.44.156:6001/cisAdmin/layoutHome"

CISUI_USERNAME = os.environ["CISUI_USERNAME"]
CISUI_PASSWORD = os.environ["CISUI_PASSWORD"]

#CIS UI XPATH
System_Configuration_tab = "xpath= //*[contains(text(),'System Configuration')]"
Show_Entries = "name: example_length"
Command_Service_IP_Tab = "xpath=//*[contains(text(),'COMMAND_SERVICE_WHITELISTED_IP')]"
Command_Service_IP_List = "xpath=//*[contains(text(),'COMMAND_SERVICE_WHITELISTED_IP')]/following-sibling::*[1]"
Command_Service_Edit_Save = "xpath= //*[contains(text(),'COMMAND_SERVICE_WHITELISTED_IP')]/following-sibling::*[2]/*[2]"
Command_Service_Input = "xpath= //*[contains(text(),'COMMAND_SERVICE_WHITELISTED_IP')]/following-sibling::*[1]/*"

Popup_Confirmation_Yes = "xpath= //*[contains(text(),'Yes')]"

Footer = "xpath=//*[@id='Footer']"
Next = "xpath=//a[text()='Next']"
Page3 = "xpath=//a[text()='3']"
Page2 = "xpath=//a[text()='2']"

Fulfillment_Service_IP_Tab = "xpath=//*[contains(text(),'FULFILLMENT_SERVICE_WHITELISTED_IP')]"
Fulfillment_Service_IP_List = "xpath=//*[contains(text(),'FULFILLMENT_SERVICE_WHITELISTED_IP')]/following-sibling::*[1]"
Fulfillment_Service_Edit_Save = "xpath= //*[contains(text(),'FULFILLMENT_SERVICE_WHITELISTED_IP')]/following-sibling::*[2]/*[2]"
Fulfillment_Service_Input = "xpath= //*[contains(text(),'FULFILLMENT_SERVICE_WHITELISTED_IP')]/following-sibling::*[1]/*"

ProductBuy_Service_IP_Tab = "xpath=//*[contains(text(),'PRODUCT_BUY_SERVICE_WHITELISTED_IP')]"
ProductBuy_Service_IP_List = "xpath=//*[contains(text(),'PRODUCT_BUY_SERVICE_WHITELISTED_IP')]/following-sibling::*[1]"
ProductBuy_Service_Edit_Save = "xpath= //*[contains(text(),'PRODUCT_BUY_SERVICE_WHITELISTED_IP')]/following-sibling::*[2]/*[2]"
ProductBuy_Service_Input = "xpath= //*[contains(text(),'PRODUCT_BUY_SERVICE_WHITELISTED_IP')]/following-sibling::*[1]/*"

USSD_Service_IP_Tab = "xpath=//*[contains(text(),'USSD_HTTP_SERVICE_WHITELISTED_IP')]"
USSD_Service_IP_List = "xpath=//*[contains(text(),'USSD_HTTP_SERVICE_WHITELISTED_IP')]/following-sibling::*[1]"
USSD_Service_Edit_Save = "xpath= //*[contains(text(),'USSD_HTTP_SERVICE_WHITELISTED_IP')]/following-sibling::*[2]/*[2]"
USSD_Service_Input = "xpath= //*[contains(text(),'USSD_HTTP_SERVICE_WHITELISTED_IP')]/following-sibling::*[1]/*"

# SMARTAPP_USERNAME = os.environ["SMARTAPP_USERNAME"]
# SMARTAPP_PASSWORD = os.environ["SMARTAPP_PASSWORD"]

# YELLOWEB_USERNAME = os.environ["YELLOWEB_USERNAME"]
# YELLOWEB_PASSWORD = os.environ["YELLOWEB_PASSWORD"]

# FLYTXT_USERNAME = os.environ["FLYTXT_USERNAME"]
# FLYTXT_PASSWORD = os.environ["FLYTXT_PASSWORD"]

# EVDS_USERNAME = os.environ["EVDS_USERNAME"]
# EVDS_PASSWORD = os.environ["EVDS_PASSWORD"]

# FACEBOOK_USERNAME = os.environ["FACEBOOK_USERNAME"]
# FACEBOOK_PASSWORD = os.environ["FACEBOOK_PASSWORD"]

# MOMO_DEBIT_COMPLETED_URL = (
#     "http://127.0.0.1:7001/cisBusiness/Mservice/MobileMoneyHttpService/debitcompleted"
# )
# MOMO_DEBIT_COMPLETED_AUTHORIZATION = os.environ["MOMO_DEBIT_COMPLETED_AUTHORIZATION"]



# CIS SSH for logs settings
SSH_HOST = "10.184.44.156"
SSH_PORT = 22
SSH_USERNAME = os.environ["SSH_USERNAME"]
SSH_PASSWORD = os.environ["SSH_PASSWORD"]

REQUEST_LOGS_PATH = "/data/fdp/logs/defaultCircle/requestLogs.log"
EDR_CSV_PATH = "/data/fdp/logs/defaultCircle/innolx156_EDR_CISOnline1.csv"
PPREPORT_LOGS_PATH = "/data/fdp/logs/defaultCircle/ppReportLogs.log"
IPAY_REPORT_PATH = "/data/cis/admin/server/rsOffline/logs/iPayCDR/iPayAuditReport.csv"
BULK_UPLOAD_PATH = "/data/cis/admin/server/BulkUploadUtility/"

RUN_GET_REQUEST_LOGS_STEP = True

# CIS DB settings
CREATE_SSH_TUNNEL_FOR_OFFLINE_DB = True
DB_NAME = "scs"
DB_USERNAME = os.environ["DB_USERNAME"]
DB_PASSWORD = os.environ["DB_PASSWORD"]
DB_HOST = "10.184.44.157"
DB_PORT = "5444"
DB_LOCAL_HOST = "127.0.0.1"
DB_LOCAL_PORT = "4445"
DB_CONNECT_STRING = ""
if CREATE_SSH_TUNNEL_FOR_OFFLINE_DB:
    DB_CONNECT_STRING = f"database='{DB_NAME}', user='{DB_USERNAME}', password='{DB_PASSWORD}', host='{DB_LOCAL_HOST}', port={DB_LOCAL_PORT}"  # noqa: E501
else:
    DB_CONNECT_STRING = f"database='{DB_NAME}', user='{DB_USERNAME}', password='{DB_PASSWORD}' host='{DB_HOST}', port={DB_PORT}"  # noqa: E501

"""Script to store the data from one testcase to another testcase testdata."""
import json


def create_data(msisdn, productid, curbal, datetdy, datapath):
    data = {
        "msisdn": msisdn,
        "product_id": productid,
        "previous_bal": curbal,
        "updated_renewal_date": datetdy,
        "runset": True,
    }
    lst = []
    with open(datapath, "r") as f:
        readdata = f.readlines()
        if len(readdata) <= 2:
            lst.append(data)
            jsondata = json.dumps(lst, indent=2)
        else:
            with open(datapath, "r") as f:
                filedata = json.load(f)
                filedata.append(data)
                jsondata = json.dumps(filedata, indent=2)
    with open(datapath, "w") as f:
        f.write(jsondata)
        f.close()

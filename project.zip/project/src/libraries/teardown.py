"""Script to run after running pabot."""
from RobotListener import RobotListener as RL  # type: ignore


def main():
    """Call RL's close method to generate and archive logs and reports."""
    RL().close()


if __name__ == "__main__":
    main()

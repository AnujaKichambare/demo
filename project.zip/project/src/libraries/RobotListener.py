"""RF Listener Interface Implementation."""
from datetime import datetime as dt

from genreport import archive, create_reports, open_reports  # type: ignore
from robot.api import logger  # type: ignore


class RobotListener:
    """RL class with listener methods."""

    ROBOT_LISTENER_API_VERSION = 2
    LIBS_WHOSE_KWS_TO_LOG_TO_CONSOLE = [
        "AirAPI",
        "CisSSH",
        "FulfillmentAPI",
        "MoMoAPI",
        "UssdAPI",
    ]

    def start_test(self, _, __):
        """Run when a test starts."""
        logger.console("")
        logger.console("-" * 60)

    def start_keyword(self, _, attributes):
        """Run when a keyword starts."""
        if attributes["libname"] in self.LIBS_WHOSE_KWS_TO_LOG_TO_CONSOLE:
            logger.console(
                f"[{dt.now().replace(microsecond=0)}] Run  {attributes['kwname']}."
            )

    def close(self):
        """Run after the execution ends."""
        timestamp = create_reports()
        archive(dt.strptime(timestamp, "%Y%m%d %H:%M:%S.%f").strftime("%Y%m%d-%H%M%S"))
        open_reports()

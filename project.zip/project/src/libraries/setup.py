"""Script to run before running robot or pabot."""
from config.fw_settings import LOGS_PATH


def main():
    """Delete all files in logs directory except output.xml file."""
    if not LOGS_PATH.exists():
        return
    for path in LOGS_PATH.iterdir():
        if path.name == "output.xml" or path.is_dir():
            continue
        path.unlink()


if __name__ == "__main__":
    main()
    print("Setup...OK")

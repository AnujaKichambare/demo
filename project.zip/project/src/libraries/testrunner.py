"""Ericsson RF Testrunner Desktop Application."""
import ctypes
import json
import os
import shlex
import signal
import subprocess
import threading
import time
import webbrowser
from datetime import timedelta
from queue import Empty, Queue
from typing import IO, Optional, Sequence

import psutil  # type: ignore
import wx  # type: ignore
import wx.aui as aui  # type: ignore
import wx.lib.agw.customtreectrl as CT  # type: ignore
from robot.api import TestSuiteBuilder  # type: ignore
from wx.grid import (  # type: ignore
    EVT_GRID_CELL_CHANGED,
    EVT_GRID_CELL_RIGHT_CLICK,
    EVT_GRID_LABEL_RIGHT_CLICK,
    Grid,
    GridCellBoolEditor,
    GridCellTextEditor,
    GridFitMode,
)
from wx.svg import SVGimage  # type: ignore

from config.fw_settings import (
    BASE_DIR,
    CUSTOM_REPORT_NAME,
    IMAGES_PATH,
    JSON_TESTDATA_PATH,
    LOGS_PATH,
    SUITES_PATH,
)

with open(BASE_DIR / "config" / "tr_config.json") as f:
    tr_config = json.load(f)


class StreamReaderThread:
    """Deamon thread to read command outputs."""

    def __init__(self, stream: IO[bytes] | None):
        """Initialize thread."""
        self._queue: Queue = Queue()
        self._thread: Optional[threading.Thread] = None
        self._stream = stream

    def run(self) -> None:
        """Start thread."""
        self._thread = threading.Thread(target=self._enqueue_output, args=(self._stream,))
        self._thread.daemon = True
        self._thread.start()

    def _enqueue_output(self, out) -> None:
        for line in iter(out.readline, b""):
            self._queue.put(line)

    def pop(self) -> str:
        """Get command output in the queue."""
        result = ""
        for _ in range(self._queue.qsize()):
            try:
                result += self._queue.get_nowait().decode("UTF-8", "replace")
            except Empty:
                pass
        return result


class Process:
    """Process for running commands."""

    def __init__(self, command: str, name: str, shell: bool = False):
        """Initialize process."""
        self._command = command if shell else shlex.split(command)
        self.name = name
        self._shell = shell
        self._process = None
        self._out_stream: Optional[StreamReaderThread] = None
        self._err_stream: Optional[StreamReaderThread] = None

    def start(self) -> None:
        """Start process to run command."""
        proc_args = dict(
            bufsize=0,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=BASE_DIR,
            shell=self._shell,
        )
        if os.sep == "\\":
            proc_args["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            proc_args["start_new_session"] = True
            proc_args["close_fds"] = True
        self._process = subprocess.Popen(self._command, **proc_args)  # type: ignore
        self._out_stream = StreamReaderThread(self._process.stdout)  # type: ignore
        self._err_stream = StreamReaderThread(self._process.stderr)  # type: ignore
        self._out_stream.run()
        self._err_stream.run()

    def output(self) -> str:
        """Get stdout of command process."""
        if not self._out_stream:
            return ""
        return self._out_stream.pop()

    def errors(self) -> str:
        """Get stderr of command process."""
        if not self._err_stream:
            return ""
        return self._err_stream.pop()

    def returncode(self) -> int:
        """Get returncode of command process."""
        if not self._process:
            return 0
        return self._process.returncode

    def is_alive(self) -> bool:
        """Check if process is running."""
        if not self._process:
            return False
        return self._process.poll() is None

    def kill(self, force: bool = False) -> None:
        """Terminate command process."""
        if not self._process:
            return
        if force:
            self._kill_children()
            self._process.kill()
        elif os.sep == "\\":
            self._process.send_signal(signal.CTRL_BREAK_EVENT)
        else:
            os.killpg(self._process.pid, signal.SIGTERM)
        if not self._is_dead():
            raise RuntimeError(f"Failed to kill process [PID: {self._process.pid}]")

    def _is_dead(self, timeout: int = 5) -> bool:
        max_time = time.time() + timeout
        while time.time() <= max_time and self.is_alive():
            time.sleep(min(0.1, timeout))
        return not self.is_alive()

    def _kill_children(self) -> None:
        if not self._process:
            return
        for p_child in psutil.Process(self._process.pid).children(recursive=True):
            p_child.kill()


class TreeItemPopupMenu(wx.Menu):
    """Popup menu to show when tree item is right clicked."""

    def __init__(self, tree_item, tree):
        """Initialize popup menu."""
        super().__init__()
        self.tree_item: CT.GenericTreeItem = tree_item
        self.tree: TestSuitesTree = tree

        chkai = wx.MenuItem(self, wx.ID_ANY, "Check All")
        unchkai = wx.MenuItem(self, wx.ID_ANY, "Uncheck All")

        self.Append(chkai)
        self.Append(unchkai)

        self.Bind(wx.EVT_MENU, self.on_checkall, chkai)
        self.Bind(wx.EVT_MENU, self.on_uncheckall, unchkai)

        if self.tree_item.GetImage() != self.tree.fldridx:
            return

        eai = wx.MenuItem(self, wx.ID_ANY, "Expand All")
        cai = wx.MenuItem(self, wx.ID_ANY, "Collapse All")

        self.AppendSeparator()
        self.Append(eai)
        self.Append(cai)

        self.Bind(wx.EVT_MENU, self.on_expandall, eai)
        self.Bind(wx.EVT_MENU, self.on_collapseall, cai)

    def _check_uncheck_all(self, checked: bool = True) -> None:
        queue: Queue = Queue()
        queue.put(self.tree_item)
        while not queue.qsize() == 0:
            item = queue.get()
            if item.GetImage() == self.tree.suiteidx and not item.IsHidden():
                for tc_item in item.GetChildren():
                    if tc_item.IsHidden():
                        continue
                    self.tree.CheckItem(tc_item, checked=checked)
            else:
                for child_item in item.GetChildren():
                    queue.put(child_item)

    def on_checkall(self, _) -> None:
        """Handle check all menu event."""
        self._check_uncheck_all()

    def on_uncheckall(self, _) -> None:
        """Handle uncheck all menu event."""
        self._check_uncheck_all(checked=False)

    def on_expandall(self, _) -> None:
        """Handle expand all menu event."""
        self.tree.ExpandAllChildren(self.tree_item)

    def on_collapseall(self, _) -> None:
        """Handle collapse all menu event."""
        for child_item in self.tree_item.GetChildren():
            self.tree.Collapse(child_item)


class TestSuitesTree(CT.CustomTreeCtrl):
    """Test Suites navigator tree."""

    def __init__(self, parent):
        """Initialize test suites tree."""
        super().__init__(parent, agwStyle=CT.TR_HAS_BUTTONS | CT.TR_TOOLTIP_ON_LONG_ITEMS)
        self.parent: LeftPanel = parent

        self._set_il()
        self.SetFont(wx.Font(*tr_config["nav_font"]))
        self.SetBackgroundColour(wx.Colour(250, 250, 250))
        self.root: CT.GenericTreeItem = self.AddRoot(SUITES_PATH.name)
        self.SetItemImage(self.root, self.fldridx, CT.TreeItemIcon_Normal)
        self.SetItemImage(self.root, self.fldropenidx, CT.TreeItemIcon_Expanded)
        self.populate()

        self.Bind(CT.EVT_TREE_ITEM_CHECKED, self.on_check)
        self.Bind(CT.EVT_TREE_ITEM_RIGHT_CLICK, self.on_rightclick)

    def _set_il(self) -> None:
        isz = (16, 16)
        il = wx.ImageList(isz[0], isz[1])
        img = SVGimage.CreateFromFile(str(IMAGES_PATH / "folder-closed.svg"))
        self.fldridx = il.Add(img.ConvertToScaledBitmap(wx.Size(isz[0], isz[1])))
        img = SVGimage.CreateFromFile(str(IMAGES_PATH / "folder-open.svg"))
        self.fldropenidx = il.Add(img.ConvertToScaledBitmap(wx.Size(isz[0], isz[1])))
        img = SVGimage.CreateFromFile(str(IMAGES_PATH / "test-suite.svg"))
        self.suiteidx = il.Add(img.ConvertToScaledBitmap(wx.Size(isz[0], isz[1])))
        img = SVGimage.CreateFromFile(str(IMAGES_PATH / "test-case.svg"))
        self.testidx = il.Add(img.ConvertToScaledBitmap(wx.Size(isz[0], isz[1])))
        self.SetImageList(il)

    def _change_item_bg_colour(self, item: CT.GenericTreeItem) -> None:
        if self.IsBold(item):
            self.SetItemBackgroundColour(item, wx.Colour(253, 253, 221))
        else:
            self.SetItemBackgroundColour(item, wx.Colour(250, 250, 250))

    def on_check(self, event) -> None:
        """Handle tree item check event."""
        item = event.GetItem()
        self.SetItemBold(item, bold=item.IsChecked())
        self._change_item_bg_colour(item)
        while parent := item.GetParent():
            has_bold_items = any(
                child_item.IsBold() for child_item in parent.GetChildren()
            )
            self.SetItemBold(parent, bold=has_bold_items)
            self._change_item_bg_colour(parent)
            item = parent

    def on_rightclick(self, event) -> None:
        """Handle tree item right click event."""
        item = event.GetItem()
        if self.GetItemType(item) == 1:
            return
        self.PopupMenu(TreeItemPopupMenu(item, self))

    def _add_ts_items(
        self, dirpath: str, filenames: list[str], parent_item: CT.GenericTreeItem
    ) -> None:
        for filename in filenames:
            if not filename.endswith(".robot"):
                continue
            ts = TestSuiteBuilder().build(os.path.join(dirpath, filename))
            ts_item = self.AppendItem(parent_item, ts.name)
            self.SetItemImage(ts_item, self.suiteidx, CT.TreeItemIcon_Normal)
            for tc in ts.tests:
                tc_item = self.AppendItem(ts_item, tc.name, ct_type=1, data=tc.doc)
                self.SetItemImage(tc_item, self.testidx, CT.TreeItemIcon_Normal)

    def _is_empty_ts_fldr_item(self, item: CT.GenericTreeItem) -> bool:
        return item.GetImage() == self.fldridx and (not item.HasChildren())

    def _add_ts_fldr_items(
        self, dirnames: list[str], parent_item: CT.GenericTreeItem
    ) -> CT.GenericTreeItem:
        next_parent_item = parent_item
        for idx, dirname in enumerate(dirnames):
            ts_fldr_item = self.AppendItem(parent_item, dirname)
            self.SetItemImage(ts_fldr_item, self.fldridx, CT.TreeItemIcon_Normal)
            self.SetItemImage(ts_fldr_item, self.fldropenidx, CT.TreeItemIcon_Expanded)
            if idx == 0:
                next_parent_item = ts_fldr_item
        if next_parent_item != parent_item:
            return next_parent_item
        return [
            item for item in self.root.GetChildren() if self._is_empty_ts_fldr_item(item)
        ][0]

    def populate(self) -> None:
        """Populate test suite tree with items."""
        parent_item = self.root
        for dirpath, dirnames, filenames in os.walk(SUITES_PATH):
            self._add_ts_items(dirpath, filenames, parent_item)
            try:
                next_parent_item = self._add_ts_fldr_items(dirnames, parent_item)
            except IndexError:
                break
            parent_item = next_parent_item
        self.Expand(self.root)

    def _test_name(self, tc_item: CT.GenericTreeItem) -> str:
        test_name = tc_item.GetText()
        while parent_item := tc_item.GetParent():
            test_name = f"{parent_item.GetText()}.{test_name}"
            tc_item = parent_item
        return test_name

    def selected_tests(self) -> list[str]:
        """Return list of test names checked to run."""
        queue: Queue = Queue()
        tests: list[str] = []
        queue.put(self.root)
        while not queue.qsize() == 0:
            item = queue.get()
            if item.GetImage() == self.suiteidx:
                tests.extend(
                    [
                        self._test_name(tc_item)
                        for tc_item in item.GetChildren()
                        if tc_item.IsChecked()
                    ]
                )
                continue
            for child_item in item.GetChildren():
                queue.put(child_item)
        return tests


class LeftPanel(wx.Panel):
    """Panel containing test navigator tree."""

    def __init__(self, parent):
        """Initialize left panel."""
        super().__init__(parent, style=wx.BORDER_SUNKEN)
        self.parent: SplitterWindow = parent
        self.SetDoubleBuffered(True)

        st = wx.StaticText(self, label="Test Navigator", style=wx.ALIGN_CENTRE_HORIZONTAL)
        st.SetBackgroundColour(wx.Colour(52, 52, 52))
        st.SetForegroundColour(wx.Colour(255, 255, 255))

        self.ts_tree = TestSuitesTree(self)
        self.search_ctrl = wx.SearchCtrl(self)
        self.search_ctrl.ShowCancelButton(True)

        vbox = wx.BoxSizer(wx.VERTICAL)
        vbox.Add(st, 0, wx.EXPAND)
        vbox.Add(self.search_ctrl, 0, wx.EXPAND | wx.ALL, 5)
        vbox.Add(self.ts_tree, 1, wx.EXPAND)
        self.SetSizer(vbox)

        self.Bind(wx.EVT_TEXT, self.on_search, self.search_ctrl)

    def on_search(self, event):
        """Search for items with text matching the search string and hide the rest."""
        search_str: str = event.GetString().lower()
        self.SetOwnBackgroundColour(
            wx.Colour(144, 238, 144) if search_str else wx.Colour(240, 240, 240)
        )
        self.Refresh()
        queue: Queue = Queue()
        queue.put(self.ts_tree.GetRootItem())
        while queue.qsize() != 0:
            item = queue.get()
            if item.GetImage() != self.ts_tree.suiteidx:
                for child_item in item.GetChildren():
                    queue.put(child_item)
                continue
            search_str_in_ts = search_str in item.GetText().lower()
            for tc in item.GetChildren():
                show = search_str in tc.GetText().lower() or search_str_in_ts
                self.ts_tree.HideItem(tc, hide=not show)
            are_all_tc_hidden = all([tc.IsHidden() for tc in item.GetChildren()])
            self.ts_tree.HideItem(item, hide=are_all_tc_hidden)
            if not are_all_tc_hidden:
                self.ts_tree.Expand(item)


class DataPage(wx.Panel):
    """Panel containing test data editor."""

    BOOL_INPUTS = ["runset", "runSelectProceedToBuyBundleStep"]

    def __init__(self, parent):
        """Initialize data page panel."""
        super().__init__(parent)
        self.parent: RightPanel = parent

        self.SetBackgroundColour(wx.Colour(250, 250, 250))
        self.SetDoubleBuffered(True)

        font: wx.Font = self.GetFont()
        font.SetPointSize(int(font.PointSize * 1.6))
        self.st = wx.StaticText(self, label=SUITES_PATH.name)
        self.st.SetFont(font)

        self.st_box = wx.StaticBox(self, label="Description")
        top_border, other_border = self.st_box.GetBordersForSizer()
        vb_sizer = wx.BoxSizer(wx.VERTICAL)
        vb_sizer.AddSpacer(top_border)
        self.st_doc = wx.StaticText(self.st_box, label="\n" * 2)
        vb_sizer.Add(
            self.st_doc, 1, wx.EXPAND | wx.BOTTOM | wx.LEFT | wx.RIGHT, other_border + 5
        )
        self.st_box.SetSizer(vb_sizer)

        self.st_err = wx.StaticText(self, style=wx.ST_ELLIPSIZE_MIDDLE)
        self.st_err.SetForegroundColour(wx.Colour(255, 0, 0))

        self.grid = Grid(self)
        self.grid.SetDefaultRowSize(30)
        self.grid.SetRowMinimalAcceptableHeight(30)
        self.grid.SetColMinimalAcceptableWidth(100)
        self.grid.SetDefaultCellFitMode(GridFitMode.Ellipsize())
        self.grid.SetDefaultCellAlignment(wx.ALIGN_LEFT, wx.ALIGN_CENTER)
        self.grid.SetLabelBackgroundColour(wx.Colour(250, 250, 250))
        self.grid.SetGridLineColour(wx.Colour(140, 140, 140))
        self.grid.CreateGrid(0, 0)

        self.ts: str = ""
        self.tc: str = ""
        self.bool_colns: list[int] = []
        self.saved: bool = True

        vbox = wx.BoxSizer(wx.VERTICAL)
        vbox.AddSpacer(5)
        vbox.Add(self.st, 0, wx.EXPAND | wx.ALL, 5)
        vbox.Add(self.st_box, 0, wx.EXPAND | wx.ALL, 5)
        vbox.Add(self.st_err, 0, wx.EXPAND | wx.LEFT | wx.BOTTOM, 5)
        vbox.Add(self.grid, 1, wx.EXPAND | wx.ALL, 5)
        self.SetSizer(vbox)

        self.grid.Bind(EVT_GRID_LABEL_RIGHT_CLICK, self.on_row_rclick)
        self.grid.Bind(EVT_GRID_CELL_CHANGED, self.on_cell_changed)
        self.grid.Bind(EVT_GRID_CELL_RIGHT_CLICK, self.on_cell_rclick)
        # self.grid.Bind(EVT_GRID_COL_AUTO_SIZE, self.on_col_autosize)

        self.grid.Bind(wx.EVT_MENU, self.on_insert_row, id=wx.ID_NEW)
        self.grid.Bind(wx.EVT_MENU, self.on_append_rows, id=wx.ID_ADD)
        self.grid.Bind(wx.EVT_MENU, self.on_delete_rows, id=wx.ID_DELETE)
        self.grid.Bind(wx.EVT_MENU, self.on_copy_up, id=wx.ID_UP)
        self.grid.Bind(wx.EVT_MENU, self.on_copy_down, id=wx.ID_DOWN)
        self.grid.Bind(wx.EVT_MENU, self.on_paste, id=wx.ID_PASTE)
        self.grid.Bind(wx.EVT_MENU, self.on_delete, id=wx.ID_REMOVE)

        self.grid.SetAcceleratorTable(
            wx.AcceleratorTable(
                [
                    (wx.ACCEL_CTRL, ord("I"), wx.ID_NEW),
                    (wx.ACCEL_ALT, ord("A"), wx.ID_ADD),
                    (wx.ACCEL_CTRL, ord("D"), wx.ID_DELETE),
                    (wx.ACCEL_ALT, wx.WXK_UP, wx.ID_UP),
                    (wx.ACCEL_ALT, wx.WXK_DOWN, wx.ID_DOWN),
                    (wx.ACCEL_CTRL, ord("V"), wx.ID_PASTE),
                    (wx.ACCEL_NORMAL, wx.WXK_DELETE, wx.ID_REMOVE),
                ]
            )
        )

    def on_row_rclick(self, event) -> None:
        """Handle right click event on row label."""
        if event.GetRow() == -1:
            return
        self.grid.SetGridCursor(event.GetRow(), 0)
        self.grid.SelectRow(event.GetRow(), addToSelected=True)
        menu = wx.Menu()
        ir = wx.MenuItem(menu, wx.ID_NEW, "Insert Set\tCtrl+I")
        ar = wx.MenuItem(menu, wx.ID_ADD, "Append Sets\tAlt+A")
        dr = wx.MenuItem(menu, wx.ID_DELETE, "Delete Sets\tCtrl+D")
        menu.Append(ir)
        menu.Append(ar)
        menu.AppendSeparator()
        menu.Append(dr)
        self.grid.PopupMenu(menu)

    def on_cell_changed(self, _) -> None:
        """Handle cell changed event."""
        self.unsave_grid()

    def on_cell_rclick(self, event) -> None:
        """Handle right click event on grid cell."""
        self.grid.SetGridCursor(event.GetRow(), event.GetCol())
        menu = wx.Menu()
        cpup = wx.MenuItem(menu, wx.ID_UP, "Copy Up\tAlt+Up")
        cpdown = wx.MenuItem(menu, wx.ID_DOWN, "Copy Down\tAlt+Down")
        paste = wx.MenuItem(menu, wx.ID_PASTE, "Paste\tCtrl+V")
        delete = wx.MenuItem(menu, wx.ID_REMOVE, "Delete\tDel")
        menu.Append(cpup)
        menu.Append(cpdown)
        menu.AppendSeparator()
        menu.Append(paste)
        menu.AppendSeparator()
        menu.Append(delete)
        self.grid.PopupMenu(menu)

    # def on_col_autosize(self, event) -> None:
    #     """Handle column autosize event."""
    #     coln = event.GetRowOrCol()
    #     self.grid.AutoSizeColumn(coln, False)

    def on_insert_row(self, _) -> None:
        """Handle insert row popup menu event."""
        rown = self.grid.GetGridCursorRow()
        if rown == -1:
            return
        self.grid.InsertRows(rown)
        for coln in self.bool_colns:
            self.grid.SetCellEditor(rown, coln, GridCellBoolEditor())
        self.unsave_grid()

    def on_append_rows(self, _) -> None:
        """Handle append rows popup menu event."""
        start_row = self.grid.GetNumberRows()
        if start_row == 0:
            return
        num_rows = wx.GetNumberFromUser(
            "Enter the number of sets to append.", "Num Sets", "Append Sets", 1, 1, 200
        )
        if num_rows == -1:
            return
        self.grid.AppendRows(num_rows)
        for rown in range(start_row, self.grid.GetNumberRows()):
            for coln in self.bool_colns:
                self.grid.SetCellEditor(rown, coln, GridCellBoolEditor())
        self.unsave_grid()

    def on_delete_rows(self, _) -> None:
        """Handle delete rows popup menu event."""
        row_count = len(self.grid.GetSelectedRows())
        if row_count == 0 or self.grid.GetNumberRows() - row_count == 0:
            return
        self.grid.SetSelectionMode(Grid.GridSelectRows)
        while self.grid.GetSelectedRows():
            block = self.grid.GetSelectedRowBlocks()[0]
            self.grid.DeleteRows(block.TopRow, block.BottomRow - block.TopRow + 1)
        self.grid.SetSelectionMode(Grid.GridSelectCells)
        self.unsave_grid()

    def on_copy_up(self, _) -> None:
        """Handle copy up popup menu event."""
        rown = self.grid.GetGridCursorRow()
        if rown in [-1, 0]:
            return
        coln = self.grid.GetGridCursorCol()
        val = self.grid.GetCellValue(rown, coln)
        for rn in range(0, rown):
            self.grid.SetCellValue(rn, coln, val)
        self.unsave_grid()

    def on_copy_down(self, _) -> None:
        """Handle copy down popup menu event."""
        rown = self.grid.GetGridCursorRow()
        if rown + 1 == self.grid.GetNumberRows():
            return
        coln = self.grid.GetGridCursorCol()
        val = self.grid.GetCellValue(rown, coln)
        for rn in range(rown + 1, self.grid.GetNumberRows()):
            self.grid.SetCellValue(rn, coln, val)
        self.unsave_grid()

    def on_paste(self, _) -> None:
        """Handle paste popup menu event."""
        text_data = wx.TextDataObject()
        success = None
        if wx.TheClipboard.Open():
            success = wx.TheClipboard.GetData(text_data)
            wx.TheClipboard.Close()
        if not success:
            return
        rown = self.grid.GetGridCursorRow()
        if rown == -1:
            return
        coln = self.grid.GetGridCursorCol()
        rows = self.grid.GetNumberRows()
        cols = self.grid.GetNumberCols()
        grid_data: list[list[str]] = [
            line.split("\t") for line in text_data.GetText().splitlines()
        ]
        if len(grid_data) > rows - rown or len(grid_data[0]) > cols - coln:
            return
        for rn, line in enumerate(grid_data, start=rown):
            for cn, val in enumerate(line, start=coln):
                self.grid.SetCellValue(rn, cn, val)
        self.unsave_grid()

    def on_delete(self, _) -> None:
        """Handle delete cell value popup menu event."""
        start_row = end_row = self.grid.GetGridCursorRow()
        if start_row == -1:
            return
        start_col = end_col = self.grid.GetGridCursorCol()
        for block in self.grid.GetSelectedBlocks():
            start_row, start_col, end_row, end_col = block.Get()
            for rown in range(start_row, end_row + 1):
                for coln in range(start_col, end_col + 1):
                    self.grid.SetCellValue(rown, coln, "")
        self.grid.SetCellValue(start_row, start_col, "")
        self.unsave_grid()

    def on_sel_changing(self, event) -> None:
        """Handle test suite navigator tree selection changing event."""
        item = event.GetItem()
        if item.GetType() != 1:
            event.Veto()
            return
        if not self.saved:
            event.Veto()
            with wx.MessageDialog(
                self, "Save test data changes before switching.", "Changes not saved."
            ) as dlg:
                dlg.ShowModal()
            return
        self.tc = item.GetText()
        self.ts = item.GetParent().GetText()
        tc_doc = item.GetData()
        item = item.GetParent()
        while (parent := item.GetParent()).GetText() != SUITES_PATH.name:
            self.ts = f"{parent.GetText()}.{self.ts}"
            item = parent
        self.st.SetLabel(f" {self.ts}.{self.tc}")
        self.st_doc.SetLabel(tc_doc)
        self.grid.ClearGrid()
        self.bool_colns.clear()
        self.grid.SetCornerLabelValue("Sets\\Inputs")
        try:
            with open(
                JSON_TESTDATA_PATH.joinpath(*self.ts.split(".")) / f"{self.tc}.json"
            ) as f:
                input_list: list[dict[str, str | bool]] = json.load(f)
        except FileNotFoundError as e:
            self.st_err.SetLabel(f"{e}")
            self._update_cols(self.grid.GetNumberCols(), 0)
            self._update_rows(self.grid.GetNumberRows(), 0)
            return
        self.st_err.SetLabel("")
        self._update_cols(self.grid.GetNumberCols(), len(input_list[0]))
        self._update_rows(self.grid.GetNumberRows(), len(input_list))
        self._populate_keys(input_list[0])
        self._populate_values(input_list)

    def _update_rows(self, cur_nrows: int, req_nrows: int) -> None:
        if req_nrows > cur_nrows:
            self.grid.AppendRows(req_nrows - cur_nrows)
        elif req_nrows < cur_nrows:
            self.grid.DeleteRows(0, cur_nrows - req_nrows)
        else:
            return

    def _update_cols(self, cur_ncols: int, req_ncols: int) -> None:
        if req_ncols > cur_ncols:
            self.grid.AppendCols(req_ncols - cur_ncols)
        elif req_ncols < cur_ncols:
            self.grid.DeleteCols(0, cur_ncols - req_ncols)
        else:
            return

    def _populate_keys(self, inputs: dict[str, str | bool]) -> None:
        for coln, key in enumerate(inputs):
            self.grid.SetColLabelValue(coln, key)
            self.grid.SetColSize(coln, -1)
            if key in self.BOOL_INPUTS:
                self.bool_colns.append(coln)

    def _populate_values(self, input_list: list[dict[str, str | bool]]) -> None:
        for rown, inputs in enumerate(input_list):
            for coln, value in enumerate(inputs.values()):
                if coln in self.bool_colns:
                    self.grid.SetCellEditor(rown, coln, GridCellBoolEditor())
                    self.grid.SetCellValue(rown, coln, "1" if value else "")
                else:
                    self.grid.SetCellEditor(rown, coln, GridCellTextEditor())
                    self.grid.SetCellValue(rown, coln, value)
                    self.grid.AutoSizeColumn(coln, False)

    def save_grid(self) -> None:
        """Save the selected test case data in json file."""
        if self.saved:
            return
        input_list = []
        for rown in range(self.grid.GetNumberRows()):
            inputs = {}
            for coln in range(self.grid.GetNumberCols()):
                val = self.grid.GetCellValue(rown, coln).strip()
                if coln in self.bool_colns:
                    val = val == "1"
                inputs[self.grid.GetColLabelValue(coln)] = val
            input_list.append(inputs)
        with open(
            JSON_TESTDATA_PATH.joinpath(*self.ts.split(".")) / f"{self.tc}.json", "w"
        ) as f:
            json.dump(input_list, f, indent=2)
        self.saved = True
        self.parent.notebook.SetPageText(0, "Test Data")

    def unsave_grid(self) -> None:
        """Show that test data is not saved."""
        self.saved = False
        self.parent.notebook.SetPageText(0, "Test Data *")


class RunPage(wx.Panel):
    """Panel containing the testrunner options."""

    def __init__(self, parent):
        """Initialize run page panel."""
        super().__init__(parent)
        self.parent: RightPanel = parent

        self.SetBackgroundColour(wx.Colour(250, 250, 250))

        self.eof: bool = False  # exit on failure
        self.rrf: bool = False  # rerun failed
        self.par: bool = False  # run in parallel
        self.running: bool = False
        self.timer = wx.Timer(self)
        self.time = timedelta()
        self.process: Optional[Process] = None
        self.tests_to_run: Sequence[str] = []
        self.act_ind: Optional[wx.ActivityIndicator] = None

        self.start_btn = self._create_btn("Start", "control-play.svg", "Start execution")
        self.stop_btn = self._create_btn(
            "Stop", "control-stop.svg", "Force Stop execution"
        )
        self.stop_btn.Disable()
        self.eds_btn = self._create_btn("Report", "e-report.svg", "Open Report")
        self.tc_count_btn = self._create_btn(
            "TC Count", "layers.svg", "Prints Test Case Count"
        )

        eof_cb = self._create_cb(
            "ExitOnFailure", self.eof, "Stop execution if any test fails."
        )
        rrf_cb = self._create_cb(
            "RerunFailed", self.rrf, "Run failed tests from previous execution."
        )
        par_cb = self._create_cb("RunInParallel", self.par, "Use pabot to execute tests.")

        hbox = wx.BoxSizer(wx.HORIZONTAL)
        hbox.SetMinSize(35, 35)
        self._add_items(
            hbox, [self.start_btn, self.stop_btn, self.eds_btn, eof_cb, rrf_cb, par_cb]
        )
        hbox.AddStretchSpacer()
        hbox.Add(self.tc_count_btn, 0, wx.ALIGN_CENTER | wx.LEFT | wx.RIGHT, 5)

        self.sb = wx.StatusBar(self)
        self.out = wx.TextCtrl(self, style=wx.TE_MULTILINE | wx.TE_READONLY | wx.TE_RICH2)

        vbox = wx.BoxSizer(wx.VERTICAL)
        vbox.Add(hbox, 0, wx.EXPAND)
        vbox.Add(self.sb, 0, wx.EXPAND)
        vbox.Add(self.out, 1, wx.EXPAND)
        self.SetSizer(vbox)

        self.Bind(wx.EVT_CHECKBOX, self.on_eof_chk, eof_cb)
        self.Bind(wx.EVT_CHECKBOX, self.on_rrf_chk, rrf_cb)
        self.Bind(wx.EVT_CHECKBOX, self.on_par_chk, par_cb)
        self.Bind(wx.EVT_BUTTON, self.on_start, self.start_btn)
        self.Bind(wx.EVT_BUTTON, self.on_stop, self.stop_btn)
        self.Bind(wx.EVT_BUTTON, self.on_eds, self.eds_btn)
        self.Bind(wx.EVT_BUTTON, self.on_tc_count, self.tc_count_btn)
        self.Bind(wx.EVT_TIMER, self.on_timer)

    def _create_btn(self, label: str, img_file: str, tooltip: str) -> wx.Button:
        btn = wx.Button(self, label=label, style=wx.BORDER_NONE)
        img = SVGimage.CreateFromFile(str(IMAGES_PATH / img_file))
        btn.SetBitmap(img.ConvertToScaledBitmap(wx.Size(16, 16)), dir=wx.RIGHT)
        btn.SetCursor(wx.Cursor(wx.CURSOR_HAND))
        btn.SetToolTip(tooltip)
        return btn

    def _create_cb(self, label: str, val: bool, tooltip: str) -> wx.CheckBox:
        cb = wx.CheckBox(self, label=label, style=wx.ALIGN_RIGHT)
        cb.SetValue(val)
        cb.SetCursor(wx.Cursor(wx.CURSOR_HAND))
        cb.SetToolTip(tooltip)
        return cb

    def _add_items(self, box: wx.BoxSizer, items: list[wx.Window]) -> None:
        for item in items:
            box.Add(item, 0, wx.ALIGN_CENTER | wx.LEFT | wx.RIGHT, 10)

    def on_eof_chk(self, event) -> None:
        """Handle ExitOnFailure checkbox event."""
        self.eof = event.IsChecked()

    def on_rrf_chk(self, event) -> None:
        """Handle RerunFailed checkbox event."""
        self.rrf = event.IsChecked()

    def on_par_chk(self, event) -> None:
        """Handle RunInParallel checkbox event."""
        self.par = event.IsChecked()

    def on_start(self, _) -> None:
        """Start test execution."""
        self.tests_to_run = self.parent.parent.left_panel.ts_tree.selected_tests()
        if not self.rrf and not self.tests_to_run:
            self.show_msg("You have not selected any tests.", "No tests selected.")
            return
        if not self.parent.data_page.saved:
            self.show_msg("Save test data changes before running.", "Changes not saved.")
            return
        self.start_execution()
        self.run_command("python ./src/libraries/setup.py", "setup")

    def on_stop(self, _) -> None:
        """Stop test execution."""
        if not self.process:
            return
        if self.process.name in ["setup", "teardown"]:
            self.append_out(
                f"\n[STOPPING {self.process.name} IS NOT ALLOWED]\n", clr=wx.RED
            )
            return
        self.stop_btn.Disable()
        self.append_out("\n[SENDING STOP SIGNAL]\n", clr=wx.RED)
        try:
            self.process.kill()
        except Exception as e:
            self.append_out(f"\nStopping process FAILED.\nError = {e}\n", clr=wx.RED)
            self.stop_btn.Enable()

    def on_eds(self, _) -> None:
        """Open custom report in default browser."""
        self.eds_btn.Disable()
        p = LOGS_PATH / f"{CUSTOM_REPORT_NAME}.html"
        if p.exists():
            webbrowser.open(str(p))
        else:
            with wx.MessageDialog(
                self, f"Report: {p} does not exist.", "Report Missing", wx.ICON_ERROR
            ) as dlg:
                dlg.ShowModal()
        self.eds_btn.Enable()

    def on_tc_count(self, _) -> None:
        """Count number of test cases."""
        self.start_execution()
        self.run_command("python ./src/libraries/count_tc.py", "count")

    def on_timer(self, _) -> None:
        """Handle timer event."""
        if not self.process:
            return
        self.time += timedelta(milliseconds=41)
        self.sb.SetStatusText(f"  Running...\t\tElapsed Time = {self.time}")
        proc_out, proc_err = self.process.output(), self.process.errors()
        if proc_out:
            self.append_out(proc_out)
        if proc_err:
            self.append_out(f"\n{proc_err}", clr=wx.RED)
        if self.process.is_alive():
            return
        if self.process.name == "setup" and self.process.returncode() == 0:
            command, name = self.make_command()
            self.run_command(command, name)
            return
        if self.process.name in ["robot", "pabot"] and not self.process.is_alive():
            self.sb.SetBackgroundColour(
                wx.Colour(250, 113, 105)
                if self.process.returncode()
                else wx.Colour(86, 232, 152)
            )
            if self.process.name == "pabot":
                self.run_command(
                    "pipenv run python ./src/libraries/teardown.py", "teardown"
                )
                return
        self.end_execution()

    def start_execution(self) -> None:
        """Tasks before starting test execution."""
        self.running = True
        self.start_btn.Disable()
        self.eds_btn.Disable()
        self.tc_count_btn.Disable()
        self.stop_btn.Enable()
        self.out.Clear()
        self.sb.SetBackgroundColour(wx.Colour(240, 240, 240, 255))
        self.sb.SetStatusText(f"  Running...\t\tElapsed Time = {self.time}")
        self.act_ind = wx.ActivityIndicator(self.sb, pos=wx.Point(120, 2))
        self.act_ind.Start()
        self.timer.Start(41)

    def end_execution(self) -> None:
        """Tasks after test execution ends."""
        self.running = False
        self.process = None
        self.start_btn.Enable()
        self.eds_btn.Enable()
        self.tc_count_btn.Enable()
        self.stop_btn.Disable()
        self.sb.SetStatusText(f"  Done !!!\tElapsed Time = {self.time}")
        self.append_out(f"\n{'=' * 50}\nEND !!!\n{'=' * 50}\n")
        self.timer.Stop()
        self.time = timedelta()
        if not self.act_ind:
            return
        self.act_ind.Stop()
        self.act_ind.Destroy()
        self.act_ind = None

    def make_command(self) -> tuple[str, str]:
        """Make the robot or pabot command depending on the run settings."""
        command = (
            "python -m pabot --pabotlib "
            if self.par
            else "python -m robot --listener ./src/libraries/RobotListener.py "
        )
        if self.rrf:
            command += f"-R ./{LOGS_PATH.name}/output.xml "
        else:
            with open(BASE_DIR / "src" / ".testnames", "w") as f:
                f.writelines([f"-t {test}\n" for test in self.tests_to_run])
            command += "--argumentfile ./src/.testnames "
        command += "--exitonfailure " if self.eof else ""
        command += f"-C off -W 90 --maxerrorlines NONE -L DEBUG --report NONE -d ./{LOGS_PATH.name} "
        command += f"./src/{SUITES_PATH.name}"
        return command, "pabot" if self.par else "robot"

    def run_command(self, command: str, name: str) -> None:
        """Run the given command."""
        self.append_out(f"{'=' * 50}\n")
        self.append_out(f"Running command: {command} ...\n")
        self.process = Process(command, name)
        try:
            self.process.start()
        except Exception as e:
            self.append_out(f"\nStarting process FAILED. Error = {e}\n", clr=wx.RED)
            self.end_execution()

    def show_msg(self, msg: str, caption: str) -> None:
        """Show message in a dialog."""
        with wx.MessageDialog(self, msg, caption) as dlg:
            if dlg.ShowModal() == wx.ID_OK:
                return

    def append_out(self, text: str, clr=wx.BLACK) -> None:
        """Append text to TextCtrl widget."""
        self.out.SetDefaultStyle(wx.TextAttr(clr))
        self.out.AppendText(text)


class RightPanel(wx.Panel):
    """Panel containing data editor and runner."""

    def __init__(self, parent):
        """Initialize right panel."""
        super().__init__(parent, style=wx.BORDER_SUNKEN)
        self.parent: SplitterWindow = parent

        self.notebook = aui.AuiNotebook(
            self,
            style=aui.AUI_NB_TOP | aui.AUI_NB_TAB_SPLIT | aui.AUI_NB_SCROLL_BUTTONS,
        )
        self.data_page = DataPage(self)
        self.run_page = RunPage(self)
        img = SVGimage.CreateFromFile(str(IMAGES_PATH / "test-data.svg"))
        self.notebook.AddPage(
            self.data_page, "Test Data", bitmap=img.ConvertToScaledBitmap(wx.Size(16, 16))
        )
        img = SVGimage.CreateFromFile(str(IMAGES_PATH / "run.svg"))
        self.notebook.AddPage(
            self.run_page, "Run", bitmap=img.ConvertToScaledBitmap(wx.Size(16, 16))
        )
        self.notebook.SetPageToolTip(0, "For editing test data of selected test case.")
        self.notebook.SetPageToolTip(1, "For running checked test cases.")

        vbox = wx.BoxSizer(wx.VERTICAL)
        vbox.Add(self.notebook, 1, wx.EXPAND)
        self.SetSizer(vbox)


class SplitterWindow(wx.SplitterWindow):
    """Splitter window for navigator and test data editor + runner."""

    def __init__(self, parent):
        """Initialize splitter window."""
        super().__init__(parent, style=wx.SP_LIVE_UPDATE)
        self.parent: RobotTestRunner = parent

        self.left_panel = LeftPanel(self)
        self.right_panel = RightPanel(self)
        self.SetMinimumPaneSize(5)
        self.SplitVertically(self.left_panel, self.right_panel, 405)

        self.Bind(CT.EVT_TREE_SEL_CHANGING, self.right_panel.data_page.on_sel_changing)


class FileMenu(wx.Menu):
    """The file menu in frame's menubar."""

    def __init__(self, parent):
        """Initialize file menu."""
        super().__init__()
        self.parent: Menubar = parent

        save_item = wx.MenuItem(self, wx.ID_SAVE, "&Save Test Data\tCtrl+S")
        quit_item = wx.MenuItem(self, wx.ID_EXIT, "&Quit\tCtrl+Q")
        self.Append(save_item)
        self.AppendSeparator()
        self.Append(quit_item)


class EditMenu(wx.Menu):
    """The edit menu in frame's menubar."""

    def __init__(self, parent):
        """Initialize edit menu."""
        super().__init__()
        self.parent: Menubar = parent

        nav_font = wx.MenuItem(
            self, wx.ID_ANY, "&Navigator Font", "Change Test Navigator font"
        )
        settings_file = wx.MenuItem(
            self, wx.ID_ANY, "&settings.py", "Edit project settings"
        )
        fw_settings_file = wx.MenuItem(
            self, wx.ID_ANY, "&fw_settings.py", "Edit framework settings"
        )
        self.Append(nav_font)
        self.AppendSeparator()
        self.Append(settings_file)
        self.Append(fw_settings_file)

        self.Bind(wx.EVT_MENU, self.on_nav_font, nav_font)
        self.Bind(wx.EVT_MENU, self.on_settings, settings_file)
        self.Bind(wx.EVT_MENU, self.on_fw_settings, fw_settings_file)

    def on_settings(self, _):
        """Edit project level settings."""
        wx.Execute("python -m idlelib ./config/settings.py")

    def on_fw_settings(self, _):
        """Edit framework level settings."""
        wx.Execute("python -m idlelib ./config/fw_settings.py")
        with wx.MessageDialog(
            self.parent,
            "Close and relaunch test runner if you have changed any of the settings other"
            + " than 'OPEN_REPORTS' and 'ARCHIVE_REPORTS', for changes to take effect.",
            "Restart test runner",
        ) as dlg:
            if dlg.ShowModal() == wx.ID_OK:
                return

    def _font_data(self, window) -> wx.FontData:
        data = wx.FontData()
        data.EnableEffects(False)
        data.SetInitialFont(window.GetFont())
        return data

    def on_nav_font(self, _) -> None:
        """Change test navigator font."""
        ts_tree = self.parent.parent.splitter.left_panel.ts_tree
        data = self._font_data(ts_tree)
        with wx.FontDialog(self.parent, data) as dlg:
            if dlg.ShowModal() != wx.ID_OK:
                return
            font: wx.Font = dlg.GetFontData().GetChosenFont()
            tr_config["nav_font"] = [
                font.PointSize,
                font.Family,
                font.Style,
                font.Weight,
                False,
                font.FaceName,
            ]
            ts_tree.SetFont(font)


class Menubar(wx.MenuBar):
    """Main frame's menubar."""

    def __init__(self, parent):
        """Initialize menubar."""
        super().__init__()
        self.parent: RobotTestRunner = parent

        file_menu = FileMenu(self)
        edit_menu = EditMenu(self)
        self.Append(file_menu, "&File")
        self.Append(edit_menu, "&Edit")


class RobotTestRunner(wx.Frame):
    """Main testrunner frame window."""

    def __init__(self):
        """Initialize main frame."""
        super().__init__(None, title=f"Ericsson RF Test Runner ({BASE_DIR})")

        if wx.SystemSettings.GetAppearance().IsDark():
            img = SVGimage.CreateFromFile(str(IMAGES_PATH / "favicon-dark.svg"))
        else:
            img = SVGimage.CreateFromFile(str(IMAGES_PATH / "favicon-light.svg"))
        icon = wx.Icon(img.ConvertToScaledBitmap(wx.Size(16, 16)))
        self.SetIcon(icon)
        self.SetFont(wx.Font(11, 75, 90, 400, False, "Consolas"))
        self.splitter = SplitterWindow(self)
        self.menubar = Menubar(self)
        self.SetSize(1000, 600)
        self.SetMenuBar(self.menubar)
        self.CreateStatusBar()
        self.Centre()

        self.Bind(wx.EVT_MENU, self.on_save, id=wx.ID_SAVE)
        self.Bind(wx.EVT_MENU, self.on_quit, id=wx.ID_EXIT)
        self.Bind(wx.EVT_CLOSE, self.on_close, self)

    def on_save(self, _) -> None:
        """Handle test data save event."""
        self.splitter.right_panel.data_page.save_grid()

    def on_quit(self, _) -> None:
        """Handle file menu quit event."""
        self.Close()

    def on_close(self, event) -> None:
        """Handle frame close event."""
        if self.splitter.right_panel.run_page.running:
            with wx.MessageDialog(
                self, "Processes are running. Stop run and try again.", "NOT ALLOWED"
            ) as dlg:
                if dlg.ShowModal() == wx.ID_OK:
                    event.Veto()
                    return
        with open(BASE_DIR / "config" / "tr_config.json", "w") as f:
            json.dump(tr_config, f)
        self.Destroy()


def main():
    """Launch testrunner."""
    app = wx.App()
    rtr = RobotTestRunner()
    myappid = "ericsson.robotframework.testrunner.2.0.0"
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
    rtr.Show()
    rtr.Maximize()
    app.MainLoop()


if __name__ == "__main__":
    main()

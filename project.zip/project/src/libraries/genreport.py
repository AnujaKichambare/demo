"""Functions to generate custom test report."""
import ast
import json
import os
import webbrowser
from datetime import datetime as dt
from pathlib import Path
from typing import Any
from zipfile import ZipFile

from jinja2 import Environment, FileSystemLoader, select_autoescape
from lxml import etree  # type: ignore
from robot.api import logger  # type: ignore

from config.fw_settings import (
    ARCHIVE_PATH,
    ARCHIVE_REPORTS,
    CUSTOM_REPORT_NAME,
    LIBRARIES_PATH,
    LOGS_PATH,
    OPEN_REPORTS,
    SUITES_PATH,
)


def _elapsed_time(
    start_time: str, end_time: str, format: str = "%Y%m%d %H:%M:%S.%f"
) -> str:
    return str(
        dt.strptime(end_time, format).replace(microsecond=0)
        - dt.strptime(start_time, format).replace(microsecond=0)
    )


def _status_info(status_elem) -> dict[str, str]:
    return {
        "start_time": status_elem.get("starttime"),
        "end_time": status_elem.get("endtime"),
        "elapsed_time": _elapsed_time(
            status_elem.get("starttime"), status_elem.get("endtime")
        ),
        "status": status_elem.get("status"),
    }


def _is_teststep_kw(kw) -> bool:
    return (
        kw.get("library") == "Framework"
        and kw.get("name") in ["Pass Step", "Fail Step", "Skip Step"]
        and kw[-1].get("status") != "NOT RUN"
    )


def _is_dataset_kw(kw) -> bool:
    return (
        kw.get("library") == "Framework"
        and kw.get("name") in ["Pass Set", "Fail Set", "Skip Set"]
        and kw[-1].get("status") != "NOT RUN"
    )


def _step_elem_parent(step_elem):
    for kw in step_elem.iterancestors("kw"):
        if kw.getparent().tag == "iter":
            return kw
    return None


def _step_name(step_elem, step_elem_parent) -> str:
    args = [arg for arg in step_elem.iterchildren("arg")]
    if len(args) == 2:
        return step_elem[-3][-2].text
    if step_elem_parent is not None:
        return step_elem_parent.get("name")
    return "Error:- Reading step name failed."


def _step_msg(step_elem) -> str:
    try:
        return step_elem[-2][-2].text
    except IndexError as e:
        return f"Error:- Reading step msg failed. {e}"


def _create_step(step_elem) -> dict[str, str]:
    step_elem_parent = _step_elem_parent(step_elem)
    if step_elem_parent is not None:
        elapsed_time = _elapsed_time(
            step_elem_parent[-1].get("starttime"), step_elem_parent[-1].get("endtime")
        )
    else:
        elapsed_time = "0:00:00"
    return {
        "step_name": _step_name(step_elem, step_elem_parent),
        "status": step_elem.get("name").split(" ")[0].upper(),
        "msg": _step_msg(step_elem),
        "elapsed_time": elapsed_time,
    }


def _add_steps(parent_elem, container: list[dict[str, str]]) -> None:
    for kw in parent_elem.iter("kw"):
        if not _is_teststep_kw(kw):
            continue
        step = _create_step(kw)
        container.append(step)


def _dataset_status(ds_elem) -> str:
    for kw in ds_elem.iter("kw"):
        if _is_dataset_kw(kw):
            return kw.get("name").split(" ")[0].upper()
    return "SKIP"


def _inputs(ds_elem) -> dict[str, Any]:
    try:
        inputs = ast.literal_eval(ds_elem[2][-2].text)
        if type(inputs) is not dict:
            raise TypeError(f"{inputs} is not of type dict")
        return inputs
    except (TypeError, SyntaxError) as e:
        return {"ERROR": f"Reading Inputs failed. {e}"}


def _create_dataset(ds_elem, set_num: int) -> dict[str, Any]:
    ds: dict[str, Any] = {
        "set_num": set_num,
        "inputs": _inputs(ds_elem),
        "status": _dataset_status(ds_elem),
        "test_steps": [],
    }
    _add_steps(ds_elem, ds["test_steps"])
    return ds


def _add_datasets(parent_elem, container: dict[str, Any]) -> None:
    for_elems = [
        elem
        for elem in parent_elem.iterchildren("for")
        if elem.get("flavor") == "IN ENUMERATE"
    ]
    if not len(for_elems):
        return
    for set_idx, ds_elem in enumerate(for_elems[0].iterchildren("iter")):
        ds = _create_dataset(ds_elem, set_idx + 1)
        container["datasets"].append(ds)
        container[f"{ds['status'].lower()}_sets"].append(ds["set_num"])


def _create_test(test_elem) -> dict[str, Any]:
    status_elem = test_elem[-1]
    test = {
        "id": test_elem.get("id"),
        "test_name": test_elem.get("name"),
        "msg": status_elem.text,
        "datasets": [],
        "pass_sets": [],
        "fail_sets": [],
        "skip_sets": [],
    }
    test.update(_status_info(status_elem))
    _add_datasets(test_elem, test)
    return test


def _add_tests(parent_elem, container: dict[str, Any]) -> None:
    for test_elem in parent_elem.iterchildren("test"):
        test = _create_test(test_elem)
        container["test_cases"][test["test_name"]] = test
        container[f"{test['status'].lower()}_tests"].append(test["test_name"])


def _suite_name(suite_elem) -> str:
    suite_name = suite_elem.get("name")
    cur_suite_elem = suite_elem
    while (parent_suite_elem := cur_suite_elem.getparent()).get(
        "name"
    ).lower() != SUITES_PATH.name:
        suite_name = f"{parent_suite_elem.get('name').lower()}.{suite_name}"
        cur_suite_elem = parent_suite_elem
    return suite_name


def _create_suite(suite_elem) -> dict[str, Any]:
    status_elem = suite_elem[-1]
    suite = {
        "id": suite_elem.get("id"),
        "suite_name": _suite_name(suite_elem),
        "test_cases": {},
        "pass_tests": [],
        "fail_tests": [],
        "skip_tests": [],
    }
    suite.update(_status_info(status_elem))
    _add_tests(suite_elem, suite)
    return suite


def _is_source_file(suite_elem) -> bool:
    source = suite_elem.get("source")
    return source and Path(source).is_file()


def _add_suites(parent_elem, container: dict[str, Any]) -> None:
    for suite_elem in parent_elem.iter("suite"):
        if not _is_source_file(suite_elem):
            continue
        suite = _create_suite(suite_elem)
        container[suite["suite_name"]] = suite


def _report_dict(root_elem) -> dict[str, Any]:
    status_elem = root_elem[0][-1]
    totalstat_elem = root_elem[1][0][0]
    report = {
        "generated": root_elem.get("generated"),
        "generator": f"src/libraries/genreport.py using {root_elem.get('generator')}",
        "pass": int(totalstat_elem.get("pass")),
        "fail": int(totalstat_elem.get("fail")),
        "skip": int(totalstat_elem.get("skip")),
        "test_suites": {},
    }
    report["total"] = report["pass"] + report["fail"] + report["skip"]
    report.update(_status_info(status_elem))
    _add_suites(root_elem, report["test_suites"])
    return report


def _json_report(report: dict[str, Any]) -> None:
    with open(LOGS_PATH / f"{CUSTOM_REPORT_NAME}.json", "w") as f:
        json.dump(report, f, indent=2)
    logger.console(LOGS_PATH / f"{CUSTOM_REPORT_NAME}.json")


def _html_report(report: dict[str, Any]) -> None:
    env = Environment(
        loader=FileSystemLoader(LIBRARIES_PATH), autoescape=select_autoescape()
    )
    template = env.get_template("template.html")
    with open(LOGS_PATH / f"{CUSTOM_REPORT_NAME}.html", "wb") as f:
        f.write(template.render(report=report).encode("utf-8"))
    logger.console(LOGS_PATH / f"{CUSTOM_REPORT_NAME}.html")


def create_reports() -> str:
    """Traverse ouput.xml to create custom json and html test reports.

    Returns the generated datetime str for archiving.
    """
    logger.console(f"{'=' * 50}\nCreating Custom Reports...")
    root_elem = etree.parse(str(LOGS_PATH / "output.xml")).getroot()
    report = _report_dict(root_elem)
    _json_report(report)
    _html_report(report)
    logger.console("OK")
    return report["generated"]


def archive(timestamp: str) -> None:
    """Archive test logs and reports in archive directory."""
    if not ARCHIVE_REPORTS:
        return
    logger.console(f"{'=' * 50}\nArchiving Logs and Reports...", newline=False)
    paths = [path for path in LOGS_PATH.iterdir() if path.name != "pabot_results"]
    os.makedirs(ARCHIVE_PATH, exist_ok=True)
    with ZipFile(
        ARCHIVE_PATH / f"du-dubai-cis-test-logs-reports-{timestamp}.zip", "w"
    ) as f:
        for path in paths:
            f.write(path, arcname=path.name)
    logger.console("OK")


def open_reports():
    """Open custom html report using default browser."""
    if not OPEN_REPORTS:
        return
    webbrowser.open(str(LOGS_PATH / f"{CUSTOM_REPORT_NAME}.html"))

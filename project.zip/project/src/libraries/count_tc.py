"""Script to count number of test cases."""
import os

from robot.api import TestSuiteBuilder  # type: ignore

from config.fw_settings import SUITES_PATH


def _main():
    count = 0
    for fname in os.listdir(SUITES_PATH):
        if not fname.endswith(".robot"):
            continue
        ts = TestSuiteBuilder().build(os.path.join(SUITES_PATH, fname))
        count += len(ts.tests)
        print(f"{len(ts.tests):4} in {ts.name}.")
    print("-" * 50)
    print(f"{count:4} in Total.")


if __name__ == "__main__":
    _main()

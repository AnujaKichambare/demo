"""Utility functions."""
import json

from config.fw_settings import JSON_TESTDATA_PATH


def load_inputs(suite_name: str, test_name: str) -> list[dict[str, str | bool]]:
    """Load the test's inputs from test's data file."""
    with open(
        JSON_TESTDATA_PATH.joinpath(*suite_name.split(".")) / f"{test_name}.json", "r"
    ) as f:
        print("hi")
        return json.load(f)


def process_inputs(inputs: dict[str, str | bool], **kwargs: str | bool):
    """Add default items to the inputs."""
    for key, value in kwargs.items():
        inputs.setdefault(key, value)

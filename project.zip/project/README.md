## DU DUBAI CIS Test Automation

### Current Test Case Count

```
  17 in Utilities.
   1 in FullfillmentServices.
--------------------------------------------------
  18 in Total.
```

### Installation

Project requires [Python](https://www.python.org/downloads/windows/) version=3.10.x to run.

1. To install Python run the **install-python.bat** script. It will ask you for the Major, Minor and Patch version numbers.
   For Major and Minor versions enter 3 and 10 respectively. For Patch version you can enter any of the available versions [here](https://www.python.org/downloads/windows/). An example will be **3.10.8** and when you run the script it will ask for inputs as shown below:

   ```sh
   Major Version?: 3
   Minor Version?: 10
   Patch Version?: 8
   ```

   To verify your python installation open cmd or pwsh and run the command
   `python --version`. It should output the installed version. For above example it will output **Python 3.10.8**

2. After installing python install the dependencies by running **setup-project.bat** script. This will install **pipenv** and then use pipenv to create a virtual environment and install packages in the virtual environment required for running the project.

3. Now create a **.env** file in the project root and copy the contents of **.env-template** file in it. Now replace the placeholders inside quotes **"..."** with appropriate values in the .env file.

### Usage

1. Launch the testrunner application by running **testrunner.bat** script.
2. You can see and edit the test-data for each test-case in the **Test Data** tab by selecting(clicking on the test-case label) the required test-case from the left panel.
3. You can check(checking the checkbox on the left of test-case label) the test-cases from the left panel and press the **Start** button in the **Run** tab to start the execution of the checked test-cases.
4. The reports are generated in the **logs-reports** folder and archived in the **archive** folder.
5. You can change settings like API URL's, DB URL's etc in **config/settings.py** file.
